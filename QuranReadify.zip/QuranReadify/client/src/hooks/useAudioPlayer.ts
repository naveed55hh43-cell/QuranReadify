import { useState, useRef, useEffect, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { getAudioUrl, DEFAULT_RECITER_ID, getReciterById } from "@/config/reciters";

const RECITER_STORAGE_KEY = "quran-selected-reciter";
const LOADING_TIMEOUT_MS = 30000; // 30 seconds - generous timeout for large files

export function useAudioPlayer() {
  const [selectedReciterId, setSelectedReciterId] = useState<string>(() => {
    const stored = localStorage.getItem(RECITER_STORAGE_KEY);
    return stored || DEFAULT_RECITER_ID;
  });
  
  const [currentSurahNumber, setCurrentSurahNumber] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Update localStorage when reciter changes
  useEffect(() => {
    localStorage.setItem(RECITER_STORAGE_KEY, selectedReciterId);
  }, [selectedReciterId]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = "";
        audioRef.current = null;
      }
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  const changeReciter = useCallback((reciterId: string) => {
    const wasPlaying = isPlaying && currentSurahNumber !== null;
    const previousSurahNumber = currentSurahNumber;
    
    // Stop current audio
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
      audioRef.current = null;
    }
    
    setSelectedReciterId(reciterId);
    setIsPlaying(false);
    setCurrentTime(0);
    setDuration(0);
    setIsLoading(false);
    
    const reciter = getReciterById(reciterId);
    toast({
      title: "Reciter changed",
      description: `Now playing: ${reciter.name}`,
    });
    
    // Auto-play the same surah if it was playing
    if (wasPlaying && previousSurahNumber !== null) {
      setTimeout(() => {
        play(previousSurahNumber);
      }, 300);
    }
  }, [isPlaying, currentSurahNumber, toast]);

  const play = useCallback(async (surahNumber: number) => {
    // Clear any existing timeout
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }

    // Toggle pause if clicking the same surah
    if (audioRef.current && currentSurahNumber === surahNumber) {
      if (audioRef.current.paused) {
        try {
          await audioRef.current.play();
          setIsPlaying(true);
        } catch (error) {
          console.error("[Audio Player] Error resuming playback:", error);
          setIsPlaying(false);
        }
      } else {
        audioRef.current.pause();
        setIsPlaying(false);
      }
      return;
    }

    // Stop previous audio
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = "";
      audioRef.current = null;
    }

    setIsLoading(true);
    setCurrentTime(0);
    setDuration(0);

    // Get CDN audio URL
    const audioUrl = getAudioUrl(selectedReciterId, surahNumber);
    console.log(`[Audio Player] 🎵 Loading Surah ${surahNumber} from CDN:`, audioUrl);

    // Create new audio element (NO crossOrigin to avoid CORS issues)
    const audio = new Audio();
    audio.preload = "auto";
    audioRef.current = audio;

    let hasStarted = false;
    let hasErrored = false;

    const cleanup = () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };

    const handleCanPlay = async () => {
      if (hasStarted || hasErrored) return;
      hasStarted = true;
      cleanup();
      
      console.log(`[Audio Player] ✓ Audio ready to play (Surah ${surahNumber})`);
      setIsLoading(false);
      
      try {
        await audio.play();
        setIsPlaying(true);
        setCurrentSurahNumber(surahNumber);
        console.log(`[Audio Player] ▶ Playback started successfully`);
      } catch (error) {
        console.error("[Audio Player] ✗ Error starting playback:", error);
        setIsPlaying(false);
        setCurrentSurahNumber(null);
        setIsLoading(false);
        
        toast({
          title: "Playback blocked",
          description: "Please interact with the page first, then try again.",
          variant: "destructive",
        });
      }
    };

    const handleError = (e?: Event) => {
      if (hasStarted || hasErrored) return;
      hasErrored = true;
      cleanup();
      
      console.error("[Audio Player] ✗ Audio loading failed:", audioUrl);
      if (audio.error) {
        const errorMessages = {
          1: "MEDIA_ERR_ABORTED - Loading was aborted",
          2: "MEDIA_ERR_NETWORK - Network error occurred", 
          3: "MEDIA_ERR_DECODE - Audio decoding failed",
          4: "MEDIA_ERR_SRC_NOT_SUPPORTED - Audio format not supported"
        };
        console.error(`[Audio Player] Error code ${audio.error.code}:`, errorMessages[audio.error.code as 1|2|3|4] || "Unknown error");
      }
      
      setIsLoading(false);
      setIsPlaying(false);
      setCurrentSurahNumber(null);
      
      if (audioRef.current === audio) {
        audioRef.current = null;
      }
      
      toast({
        title: "Unable to load audio",
        description: "Please check your internet connection and try again.",
        variant: "destructive",
      });
    };

    const handleEnded = () => {
      console.log(`[Audio Player] ■ Playback ended (Surah ${surahNumber})`);
      setIsPlaying(false);
      setCurrentSurahNumber(null);
      setCurrentTime(0);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleLoadedMetadata = () => {
      console.log(`[Audio Player] ℹ Metadata loaded - Duration: ${audio.duration.toFixed(1)}s`);
      setDuration(audio.duration);
    };

    // Event listeners
    audio.addEventListener("canplay", handleCanPlay);
    audio.addEventListener("error", handleError);
    audio.addEventListener("ended", handleEnded);
    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("loadedmetadata", handleLoadedMetadata);

    // Set timeout for loading
    timeoutRef.current = setTimeout(() => {
      if (!hasStarted && !hasErrored) {
        console.warn(`[Audio Player] ⏱ Loading timeout after ${LOADING_TIMEOUT_MS}ms`);
        handleError();
      }
    }, LOADING_TIMEOUT_MS);

    // Start loading
    audio.src = audioUrl;
    audio.load();
  }, [selectedReciterId, currentSurahNumber, toast]);

  const stop = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsPlaying(false);
      setCurrentSurahNumber(null);
      setCurrentTime(0);
      setIsLoading(false);
    }
  }, []);

  const seek = useCallback((time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  }, []);

  return {
    selectedReciterId,
    currentSurahNumber,
    isPlaying,
    isLoading,
    currentTime,
    duration,
    play,
    stop,
    seek,
    changeReciter,
  };
}
