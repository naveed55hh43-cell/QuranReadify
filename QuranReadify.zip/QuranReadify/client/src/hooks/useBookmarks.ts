import { useState, useEffect } from "react";
import type { Bookmark } from "@shared/schema";

export function useBookmarks() {
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem("quran-bookmarks");
    if (stored) {
      try {
        setBookmarks(JSON.parse(stored));
      } catch (error) {
        console.error("Failed to parse bookmarks:", error);
      }
    }
  }, []);

  const addBookmark = (surahNumber: number) => {
    const newBookmark: Bookmark = {
      surahNumber,
      timestamp: Date.now(),
    };
    const updated = [...bookmarks, newBookmark];
    setBookmarks(updated);
    localStorage.setItem("quran-bookmarks", JSON.stringify(updated));
  };

  const removeBookmark = (surahNumber: number) => {
    const updated = bookmarks.filter(b => b.surahNumber !== surahNumber);
    setBookmarks(updated);
    localStorage.setItem("quran-bookmarks", JSON.stringify(updated));
  };

  const isBookmarked = (surahNumber: number) => {
    return bookmarks.some(b => b.surahNumber === surahNumber);
  };

  const toggleBookmark = (surahNumber: number) => {
    if (isBookmarked(surahNumber)) {
      removeBookmark(surahNumber);
    } else {
      addBookmark(surahNumber);
    }
  };

  return {
    bookmarks,
    addBookmark,
    removeBookmark,
    isBookmarked,
    toggleBookmark,
  };
}
