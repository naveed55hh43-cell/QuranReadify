import { Link, useLocation } from "wouter";
import { BookOpen, HandHeart, Calendar, Moon, Sun, BookText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/contexts/ThemeContext";

const navItems = [
  { path: "/", label: "Quran", labelArabic: "القرآن", icon: BookOpen },
  { path: "/hadith", label: "Hadith", labelArabic: "حديث", icon: BookText },
  { path: "/duas", label: "Daily Duas", labelArabic: "أدعية", icon: HandHeart },
  { path: "/calendar", label: "Prayer Times", labelArabic: "الصلوات", icon: Calendar }
];

export function Navigation() {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-gradient-to-r from-pink-200 via-pink-100 to-teal-200 dark:from-pink-900/40 dark:via-purple-900/30 dark:to-teal-900/40 backdrop-blur supports-[backdrop-filter]:bg-gradient-to-r">
      <div className="container mx-auto px-4">
        <div className="flex h-16 md:h-20 items-center justify-between">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center gap-3 hover:opacity-80 transition-opacity" data-testid="link-home-logo">
              <div className="flex items-center justify-center w-10 h-10 md:w-12 md:h-12 bg-primary rounded-full">
                <BookOpen className="h-5 w-5 md:h-6 md:w-6 text-primary-foreground" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-lg md:text-xl font-bold text-foreground">QuranReadify</h1>
                <p className="text-xs md:text-sm font-arabic text-muted-foreground">القرآن الكريم</p>
              </div>
            </a>
          </Link>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 md:gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path;
              
              return (
                <Link key={item.path} href={item.path}>
                  <a
                    className={`
                      flex items-center gap-2 px-3 md:px-4 py-2 rounded-lg transition-all
                      ${isActive 
                        ? 'bg-primary text-primary-foreground shadow-md' 
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                      }
                    `}
                    data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
                  >
                    <Icon className="h-4 w-4 md:h-5 md:w-5" />
                    <span className="hidden md:inline text-sm md:text-base font-medium">{item.label}</span>
                    <span className="md:hidden text-xs">{item.label.split(' ')[0]}</span>
                  </a>
                </Link>
              );
            })}
          </nav>

          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            className="ml-auto md:ml-4"
            data-testid="button-theme-toggle"
          >
            {theme === "dark" ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
            <span className="sr-only">Toggle theme</span>
          </Button>
        </div>
      </div>
    </header>
  );
}
