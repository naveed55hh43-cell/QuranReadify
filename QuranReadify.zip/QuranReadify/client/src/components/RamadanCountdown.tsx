import { useEffect, useState } from "react";
import { Moon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface TimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export function RamadanCountdown() {
  const [timeRemaining, setTimeRemaining] = useState<TimeRemaining>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const ramadanEndDate = new Date('2026-03-20T00:00:00');

    const updateCountdown = () => {
      const now = new Date();
      const difference = ramadanEndDate.getTime() - now.getTime();

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        setTimeRemaining({ days, hours, minutes, seconds });
      } else {
        setTimeRemaining({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Card 
      className="w-full overflow-hidden border-l-4 border-l-accent shadow-md bg-gradient-to-br from-primary/5 to-accent/5 hover:shadow-lg transition-all"
      data-testid="card-ramadan-countdown"
    >
      <CardContent className="p-6 md:p-8">
        {/* Header */}
        <div className="flex items-center justify-center gap-3 mb-6">
          <Moon className="h-6 w-6 md:h-7 md:w-7 text-accent animate-glow" />
          <h2 className="text-2xl md:text-3xl font-bold text-foreground text-center">
            Ramadan Kareem
          </h2>
          <Moon className="h-6 w-6 md:h-7 md:w-7 text-accent animate-glow" />
        </div>

        {/* Subtitle */}
        <p className="text-center text-muted-foreground mb-6 text-sm md:text-base">
          Time Remaining Till Eid-ul-Fitr
        </p>

        {/* Countdown Display */}
        <div className="grid grid-cols-4 gap-3 md:gap-6">
          {/* Days */}
          <div className="text-center">
            <div className="bg-card rounded-xl p-4 md:p-6 shadow-md border border-border hover:border-accent transition-all">
              <div className="text-3xl md:text-4xl lg:text-5xl font-bold text-accent mb-2 animate-pulse-subtle">
                {timeRemaining.days}
              </div>
              <div className="text-xs md:text-sm text-muted-foreground font-medium uppercase">
                Days
              </div>
            </div>
          </div>

          {/* Hours */}
          <div className="text-center">
            <div className="bg-card rounded-xl p-4 md:p-6 shadow-md border border-border hover:border-accent transition-all">
              <div className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-2 animate-pulse-subtle">
                {timeRemaining.hours}
              </div>
              <div className="text-xs md:text-sm text-muted-foreground font-medium uppercase">
                Hours
              </div>
            </div>
          </div>

          {/* Minutes */}
          <div className="text-center">
            <div className="bg-card rounded-xl p-4 md:p-6 shadow-md border border-border hover:border-accent transition-all">
              <div className="text-3xl md:text-4xl lg:text-5xl font-bold text-primary mb-2 animate-pulse-subtle">
                {timeRemaining.minutes}
              </div>
              <div className="text-xs md:text-sm text-muted-foreground font-medium uppercase">
                Mins
              </div>
            </div>
          </div>

          {/* Seconds */}
          <div className="text-center">
            <div className="bg-card rounded-xl p-4 md:p-6 shadow-md border border-border hover:border-accent transition-all">
              <div className="text-3xl md:text-4xl lg:text-5xl font-bold text-accent mb-2">
                {timeRemaining.seconds}
              </div>
              <div className="text-xs md:text-sm text-muted-foreground font-medium uppercase">
                Secs
              </div>
            </div>
          </div>
        </div>

        {/* Footer Message */}
        <div className="mt-6 text-center">
          <p className="text-sm md:text-base font-arabic text-primary">
            رَمَضَانُ مُبَارَكٌ
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
