import { Play, Pause, Bookmark, BookmarkCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { Surah } from "@shared/schema";

interface SurahCardProps {
  surah: Surah;
  isPlaying: boolean;
  isBookmarked: boolean;
  onPlay: () => void;
  onBookmark: () => void;
  onClick: () => void;
}

export function SurahCard({
  surah,
  isPlaying,
  isBookmarked,
  onPlay,
  onBookmark,
  onClick,
}: SurahCardProps) {
  return (
    <Card
      className="group hover-elevate active-elevate-2 transition-all overflow-hidden"
      data-testid={`card-surah-${surah.number}`}
    >
      <div className="flex">
        <div className="w-1 bg-primary flex-shrink-0" />
        <div className="p-6 flex items-center gap-4 flex-1">
        <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center border-2 border-primary/20">
          <span className="text-lg font-semibold text-primary" data-testid={`text-surah-number-${surah.number}`}>
            {surah.number}
          </span>
        </div>

        <button
          onClick={onClick}
          className="flex-1 text-left min-w-0"
          data-testid={`button-surah-${surah.number}`}
        >
          <div className="flex flex-col gap-1">
            <h3 className="text-2xl font-arabic font-bold text-foreground leading-relaxed" data-testid={`text-surah-arabic-${surah.number}`}>
              {surah.name}
            </h3>
            <div className="flex items-center gap-2 flex-wrap">
              <p className="text-lg font-medium text-foreground" data-testid={`text-surah-english-${surah.number}`}>
                {surah.englishName}
              </p>
              <span className="text-muted-foreground">•</span>
              <p className="text-sm text-muted-foreground" data-testid={`text-surah-translation-${surah.number}`}>
                {surah.englishNameTranslation}
              </p>
            </div>
            <div className="flex items-center gap-2 flex-wrap mt-1">
              <Badge variant="secondary" className="text-xs">
                {surah.numberOfAyahs} verses
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {surah.revelationType}
              </Badge>
            </div>
          </div>
        </button>

        <div className="flex items-center gap-2 flex-shrink-0">
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              onBookmark();
            }}
            className="rounded-full"
            data-testid={`button-bookmark-${surah.number}`}
          >
            {isBookmarked ? (
              <BookmarkCheck className="h-5 w-5 text-primary fill-primary" />
            ) : (
              <Bookmark className="h-5 w-5" />
            )}
          </Button>
          <Button
            variant={isPlaying ? "default" : "outline"}
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              onPlay();
            }}
            className="rounded-full"
            data-testid={`button-play-${surah.number}`}
          >
            {isPlaying ? (
              <Pause className="h-5 w-5" />
            ) : (
              <Play className="h-5 w-5" />
            )}
          </Button>
        </div>
      </div>
      </div>
    </Card>
  );
}
