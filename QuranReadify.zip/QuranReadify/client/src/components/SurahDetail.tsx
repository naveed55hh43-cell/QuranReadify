import { X, Play, Pause } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AyahCard } from "./AyahCard";
import type { Surah } from "@shared/schema";

interface SurahDetailProps {
  surah: Surah;
  onClose: () => void;
  isPlaying: boolean;
  onPlay: () => void;
}

export function SurahDetail({ surah, onClose, isPlaying, onPlay }: SurahDetailProps) {
  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-md">
      <div className="h-full flex flex-col">
        <div className="border-b bg-card">
          <div className="max-w-4xl mx-auto px-4 md:px-8 py-6">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <h2
                  className="text-3xl md:text-4xl font-arabic font-bold text-foreground leading-relaxed mb-3"
                  dir="rtl"
                  lang="ar"
                  data-testid={`text-detail-arabic-${surah.number}`}
                >
                  {surah.name}
                </h2>
                <div className="space-y-1">
                  <h3 className="text-xl md:text-2xl font-semibold text-foreground" data-testid={`text-detail-english-${surah.number}`}>
                    {surah.englishName}
                  </h3>
                  <p className="text-base text-muted-foreground" data-testid={`text-detail-translation-${surah.number}`}>
                    {surah.englishNameTranslation}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {surah.revelationType} • {surah.numberOfAyahs} verses
                  </p>
                </div>
                {surah.number !== 1 && surah.number !== 9 && (
                  <p
                    className="text-3xl font-arabic text-center mt-6 text-foreground leading-loose"
                    dir="rtl"
                    lang="ar"
                  >
                    بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ
                  </p>
                )}
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <Button
                  variant={isPlaying ? "default" : "outline"}
                  size="icon"
                  onClick={onPlay}
                  className="rounded-full"
                  data-testid={`button-detail-play-${surah.number}`}
                >
                  {isPlaying ? (
                    <Pause className="h-5 w-5" />
                  ) : (
                    <Play className="h-5 w-5" />
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="rounded-full"
                  data-testid={`button-close-detail-${surah.number}`}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="max-w-4xl mx-auto px-4 md:px-8 py-8">
            <div className="space-y-6">
              {surah.ayahs.map((ayah) => (
                <AyahCard key={ayah.number} ayah={ayah} surahNumber={surah.number} />
              ))}
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
