import { Sparkles } from "lucide-react";
import { Card } from "@/components/ui/card";

export function FeaturedAyah() {
  return (
    <Card 
      className="w-full overflow-hidden border-none shadow-lg bg-[#fdf9f2] dark:bg-[#2a2520] animate-fade-in"
      data-testid="card-featured-ayah"
    >
      <div className="relative p-8 md:p-12">
        {/* Decorative Element */}
        <div className="flex justify-center mb-6">
          <div className="flex items-center gap-2 text-accent">
            <div className="h-px w-12 bg-gradient-to-r from-transparent to-accent"></div>
            <Sparkles className="h-5 w-5 animate-pulse" />
            <div className="h-px w-12 bg-gradient-to-l from-transparent to-accent"></div>
          </div>
        </div>

        {/* Arabic Text - Top, Large, Gold */}
        <div className="mb-8 text-center">
          <p 
            className="text-4xl md:text-5xl lg:text-6xl font-arabic text-accent leading-loose animate-slide-up"
            lang="ar" 
            dir="rtl"
          >
            لَا تَحْزَنْ إِنَّ اللَّهَ مَعَنَا
          </p>
        </div>

        {/* Gold Divider */}
        <div className="flex justify-center my-6">
          <div className="h-px w-32 bg-gradient-to-r from-transparent via-accent to-transparent"></div>
        </div>

        {/* Urdu Translation - Center, Bold, Teal */}
        <div className="mb-6 text-center">
          <p 
            className="text-2xl md:text-3xl font-urdu font-bold text-primary leading-relaxed"
            lang="ur" 
            dir="rtl"
          >
            غم نہ کرو، بے شک اللہ تمہارے ساتھ ہے۔
          </p>
        </div>

        {/* Gold Divider */}
        <div className="flex justify-center my-6">
          <div className="h-px w-32 bg-gradient-to-r from-transparent via-accent to-transparent"></div>
        </div>

        {/* English Translation - Bottom, Italic, Soft Gray */}
        <div className="text-center">
          <p className="text-lg md:text-xl italic text-muted-foreground leading-relaxed">
            "Do not grieve; indeed, Allah is with us."
          </p>
        </div>

        {/* Surah Reference */}
        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground font-medium">
            — Surah At-Tawbah (9:40)
          </p>
        </div>
      </div>
    </Card>
  );
}
