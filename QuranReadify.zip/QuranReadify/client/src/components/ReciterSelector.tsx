import { Music } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useReciter, RECITERS } from "@/contexts/ReciterContext";

export function ReciterSelector() {
  const { selectedReciter, setSelectedReciter } = useReciter();

  const handleValueChange = (value: string) => {
    const reciter = RECITERS.find(r => r.id === value);
    if (reciter) {
      setSelectedReciter(reciter);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="rounded-full" data-testid="button-reciter-selector">
          <Music className="h-5 w-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel>Select Reciter</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuRadioGroup value={selectedReciter.id} onValueChange={handleValueChange}>
          {RECITERS.map((reciter) => (
            <DropdownMenuRadioItem
              key={reciter.id}
              value={reciter.id}
              className="cursor-pointer"
              data-testid={`reciter-option-${reciter.id}`}
            >
              <div className="flex-1 min-w-0 pr-2">
                <div className="font-medium text-sm truncate">{reciter.name}</div>
                <div className="text-xs text-muted-foreground font-arabic" dir="rtl">
                  {reciter.arabicName}
                </div>
              </div>
            </DropdownMenuRadioItem>
          ))}
        </DropdownMenuRadioGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
