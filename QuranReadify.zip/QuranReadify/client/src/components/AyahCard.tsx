import { Card } from "@/components/ui/card";
import type { Ayah } from "@shared/schema";

interface AyahCardProps {
  ayah: Ayah;
  surahNumber: number;
}

export function AyahCard({ ayah, surahNumber }: AyahCardProps) {
  return (
    <Card className="p-6" data-testid={`card-ayah-${surahNumber}-${ayah.number}`}>
      <div className="flex flex-col gap-6">
        <div className="flex items-start gap-4">
          <div className="flex-shrink-0 w-8 h-8 rounded-full border-2 border-primary/30 flex items-center justify-center">
            <span className="text-sm font-medium text-primary" data-testid={`text-ayah-number-${surahNumber}-${ayah.number}`}>
              {ayah.number}
            </span>
          </div>
          <div className="flex-1 space-y-4">
            <p
              className="text-2xl md:text-3xl font-arabic leading-loose text-right text-foreground"
              dir="rtl"
              lang="ar"
              data-testid={`text-ayah-arabic-${surahNumber}-${ayah.number}`}
            >
              {ayah.text}
            </p>
            <p
              className="text-base md:text-lg font-serif leading-relaxed text-muted-foreground"
              data-testid={`text-ayah-translation-${surahNumber}-${ayah.number}`}
            >
              {ayah.translation}
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
}
