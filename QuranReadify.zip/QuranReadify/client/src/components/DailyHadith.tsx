import { useEffect, useState } from "react";
import { BookText, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { fetchHadithBook, getDailyHadith } from "@/utils/hadithCache";

export function DailyHadith() {
  const [hadith, setHadith] = useState<{
    arabic: string;
    english: string;
    urdu: string;
    number: number;
    book: string;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadDailyHadith() {
      try {
        const { bookNumber, hadithIndex } = getDailyHadith();
        
        const [araBook, engBook, urdBook] = await Promise.all([
          fetchHadithBook(bookNumber, 'ara'),
          fetchHadithBook(bookNumber, 'eng'),
          fetchHadithBook(bookNumber, 'urd'),
        ]);

        const araHadith = araBook.hadiths[hadithIndex];
        const engHadith = engBook.hadiths[hadithIndex];
        const urdHadith = urdBook.hadiths[hadithIndex];

        if (araHadith && engHadith && urdHadith) {
          setHadith({
            arabic: araHadith.text,
            english: engHadith.text,
            urdu: urdHadith.text,
            number: engHadith.hadithnumber,
            book: Object.values(engBook.metadata.section)[0] || `Book ${bookNumber}`,
          });
        } else {
          setError("Hadith not found");
        }
      } catch (error) {
        console.error("Failed to load daily hadith:", error);
        setError("Failed to load daily hadith. Please try again later.");
      } finally {
        setLoading(false);
      }
    }

    loadDailyHadith();
  }, []);

  if (loading) {
    return (
      <Card className="w-full border-l-4 border-l-accent shadow-md" data-testid="card-daily-hadith-loading">
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (error || !hadith) {
    return (
      <Card className="w-full border-l-4 border-l-destructive shadow-md" data-testid="card-daily-hadith-error">
        <CardHeader>
          <CardTitle className="text-xl text-foreground flex items-center gap-2">
            <BookText className="h-5 w-5" />
            Hadith of the Day
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            {error || "Unable to load today's hadith. Please try again later."}
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full border-l-4 border-l-accent shadow-md hover:shadow-lg transition-all bg-gradient-to-br from-card to-accent/5" data-testid="card-daily-hadith">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-accent/20">
            <BookText className="h-6 w-6 text-accent" />
          </div>
          <div>
            <CardTitle className="text-xl md:text-2xl text-foreground">
              Hadith of the Day
            </CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Sahih al-Bukhari • {hadith.book} • #{hadith.number}
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Arabic Text - Top with Gold Color */}
        <div className="p-6 rounded-lg bg-gradient-to-br from-accent/10 to-accent/5 border-2 border-accent/30">
          <p 
            className="text-2xl md:text-3xl font-arabic text-accent text-right leading-loose"
            lang="ar" 
            dir="rtl"
          >
            {hadith.arabic}
          </p>
        </div>

        {/* Urdu Text - Center */}
        <div className="p-4 rounded-lg bg-background/60 border border-border">
          <Badge variant="outline" className="mb-2">اردو</Badge>
          <p className="text-lg md:text-xl font-urdu text-right leading-relaxed" lang="ur" dir="rtl">
            {hadith.urdu}
          </p>
        </div>
        
        {/* English Text - Bottom */}
        <div className="p-4 rounded-lg bg-background/60 border border-border">
          <Badge variant="outline" className="mb-2">English</Badge>
          <p className="text-base md:text-lg leading-relaxed text-muted-foreground">
            {hadith.english}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
