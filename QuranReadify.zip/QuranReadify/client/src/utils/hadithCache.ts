const CACHE_KEY_PREFIX = 'hadith_cache_';
const CACHE_EXPIRY = 7 * 24 * 60 * 60 * 1000; // 7 days

interface HadithBook {
  metadata: {
    name: string;
    section: Record<string, string>;
    section_detail: Record<string, any>;
  };
  hadiths: Array<{
    hadithnumber: number;
    arabicnumber: number;
    text: string;
    grades: any[];
    reference: {
      book: number;
      hadith: number;
    };
  }>;
}

interface CachedData<T> {
  data: T;
  timestamp: number;
}

export async function fetchHadithBook(
  bookNumber: number,
  language: 'eng' | 'urd' | 'ara' = 'eng'
): Promise<HadithBook> {
  const cacheKey = `${CACHE_KEY_PREFIX}${language}_${bookNumber}`;
  
  const cached = localStorage.getItem(cacheKey);
  if (cached) {
    try {
      const { data, timestamp }: CachedData<HadithBook> = JSON.parse(cached);
      if (Date.now() - timestamp < CACHE_EXPIRY) {
        return data;
      }
    } catch (e) {
      localStorage.removeItem(cacheKey);
    }
  }
  
  const url = `https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions/${language}-bukhari/${bookNumber}.json`;
  const response = await fetch(url);
  
  if (!response.ok) {
    throw new Error(`Failed to fetch hadith book ${bookNumber}`);
  }
  
  const data: HadithBook = await response.json();
  
  localStorage.setItem(
    cacheKey,
    JSON.stringify({
      data,
      timestamp: Date.now(),
    } as CachedData<HadithBook>)
  );
  
  return data;
}

export async function fetchMultipleHadithBooks(
  bookNumbers: number[],
  language: 'eng' | 'urd' | 'ara' = 'eng'
): Promise<Map<number, HadithBook>> {
  const results = await Promise.all(
    bookNumbers.map(async (num) => {
      try {
        const book = await fetchHadithBook(num, language);
        return [num, book] as [number, HadithBook];
      } catch (error) {
        console.error(`Failed to fetch book ${num}:`, error);
        return null;
      }
    })
  );
  
  return new Map(results.filter((r): r is [number, HadithBook] => r !== null));
}

const BOOK_HADITH_COUNTS = [
  { book: 1, count: 7 },
  { book: 2, count: 51 },
  { book: 3, count: 76 },
  { book: 4, count: 113 },
  { book: 5, count: 46 },
  { book: 6, count: 40 },
  { book: 7, count: 15 },
  { book: 8, count: 172 },
  { book: 9, count: 81 },
  { book: 10, count: 273 },
];

const totalHadiths = BOOK_HADITH_COUNTS.reduce((sum, { count }) => sum + count, 0);

export function getDailyHadith(): { bookNumber: number; hadithIndex: number } {
  const today = new Date();
  const start = new Date(today.getFullYear(), 0, 0);
  const diff = today.getTime() - start.getTime();
  const oneDay = 1000 * 60 * 60 * 24;
  const dayOfYear = Math.floor(diff / oneDay);
  
  let hadithOfDay = dayOfYear % totalHadiths;
  
  for (const { book, count } of BOOK_HADITH_COUNTS) {
    if (hadithOfDay < count) {
      return {
        bookNumber: book,
        hadithIndex: hadithOfDay,
      };
    }
    hadithOfDay -= count;
  }
  
  return { bookNumber: 1, hadithIndex: 0 };
}

export function clearHadithCache(): void {
  const keys = Object.keys(localStorage);
  keys.forEach((key) => {
    if (key.startsWith(CACHE_KEY_PREFIX)) {
      localStorage.removeItem(key);
    }
  });
}
