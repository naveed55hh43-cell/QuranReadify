import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookmarkPlus } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Dua {
  id: number;
  titleArabic: string;
  titleEnglish: string;
  category: string;
  textArabic: string;
  textEnglish: string;
  context: string;
}

const duas: Dua[] = [
  {
    id: 1,
    titleArabic: "دعاء الاستيقاظ",
    titleEnglish: "Upon Waking Up",
    category: "Morning",
    textArabic: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ",
    textEnglish: "All praise is for Allah who gave us life after having taken it from us, and unto Him is the resurrection.",
    context: "Recite this dua when you wake up in the morning"
  },
  {
    id: 2,
    titleArabic: "دعاء قبل الطعام",
    titleEnglish: "Before Eating",
    category: "Meals",
    textArabic: "بِسْمِ اللَّهِ",
    textEnglish: "In the name of Allah",
    context: "Say Bismillah before starting any meal"
  },
  {
    id: 3,
    titleArabic: "دعاء بعد الطعام",
    titleEnglish: "After Eating",
    category: "Meals",
    textArabic: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ",
    textEnglish: "All praise is for Allah who fed us and gave us drink, and made us Muslims.",
    context: "Recite after completing your meal"
  },
  {
    id: 4,
    titleArabic: "دعاء الخروج من المنزل",
    titleEnglish: "Leaving Home",
    category: "Travel",
    textArabic: "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ، لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
    textEnglish: "In the name of Allah, I place my trust in Allah; there is no might and no power except with Allah.",
    context: "Say this when leaving your house"
  },
  {
    id: 5,
    titleArabic: "دعاء دخول المنزل",
    titleEnglish: "Entering Home",
    category: "Home",
    textArabic: "بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى رَبِّنَا تَوَكَّلْنَا",
    textEnglish: "In the name of Allah we enter, in the name of Allah we leave, and upon our Lord we place our trust.",
    context: "Recite when entering your home"
  },
  {
    id: 6,
    titleArabic: "دعاء ركوب المركبة",
    titleEnglish: "Riding Transport",
    category: "Travel",
    textArabic: "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ، وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ",
    textEnglish: "Glory unto Him who has subjected this to us, and we ourselves were not capable of that. And surely unto our Lord we are returning.",
    context: "Say when boarding any vehicle"
  },
  {
    id: 7,
    titleArabic: "دعاء السفر",
    titleEnglish: "Traveling",
    category: "Travel",
    textArabic: "اللَّهُمَّ إِنَّا نَسْأَلُكَ فِي سَفَرِنَا هَذَا الْبِرَّ وَالتَّقْوَى، وَمِنَ الْعَمَلِ مَا تَرْضَى",
    textEnglish: "O Allah, we ask You in this journey of ours for righteousness, piety, and such deeds that You are pleased with.",
    context: "Recite when beginning a journey"
  },
  {
    id: 8,
    titleArabic: "دعاء دخول المسجد",
    titleEnglish: "Entering Mosque",
    category: "Prayer",
    textArabic: "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ",
    textEnglish: "O Allah, open for me the doors of Your mercy.",
    context: "Say with right foot when entering the mosque"
  },
  {
    id: 9,
    titleArabic: "دعاء الخروج من المسجد",
    titleEnglish: "Leaving Mosque",
    category: "Prayer",
    textArabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ",
    textEnglish: "O Allah, I ask You from Your bounty.",
    context: "Say with left foot when leaving the mosque"
  },
  {
    id: 10,
    titleArabic: "دعاء النوم",
    titleEnglish: "Before Sleep",
    category: "Night",
    textArabic: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
    textEnglish: "In Your name, O Allah, I die and I live.",
    context: "Recite before going to sleep"
  },
  {
    id: 11,
    titleArabic: "دعاء الهم والحزن",
    titleEnglish: "For Anxiety & Grief",
    category: "Hardship",
    textArabic: "اللَّهُمَّ إِنِّي عَبْدُكَ، ابْنُ عَبْدِكَ، ابْنُ أَمَتِكَ، نَاصِيَتِي بِيَدِكَ، مَاضٍ فِيَّ حُكْمُكَ، عَدْلٌ فِيَّ قَضَاؤُكَ",
    textEnglish: "O Allah, I am Your servant, son of Your servant, son of Your maidservant. My forelock is in Your hand, Your command over me is forever executed.",
    context: "Recite when feeling distress or sadness"
  },
  {
    id: 12,
    titleArabic: "الاستغفار",
    titleEnglish: "Seeking Forgiveness",
    category: "Repentance",
    textArabic: "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
    textEnglish: "I seek the forgiveness of Allah and repent to Him.",
    context: "Seek Allah's forgiveness throughout the day"
  },
  {
    id: 13,
    titleArabic: "دعاء المطر",
    titleEnglish: "During Rain",
    category: "Weather",
    textArabic: "اللَّهُمَّ صَيِّبًا نَافِعًا",
    textEnglish: "O Allah, (bring) beneficial rain.",
    context: "Say when it rains"
  },
  {
    id: 14,
    titleArabic: "دعاء الرياح",
    titleEnglish: "During Wind",
    category: "Weather",
    textArabic: "اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَهَا وَخَيْرَ مَا فِيهَا، وَأَعُوذُ بِكَ مِنْ شَرِّهَا وَشَرِّ مَا فِيهَا",
    textEnglish: "O Allah, I ask You for its goodness and the goodness within it, and I seek refuge in You from its evil and the evil within it.",
    context: "Recite when strong winds blow"
  },
  {
    id: 15,
    titleArabic: "دعاء الشكر",
    titleEnglish: "Gratitude",
    category: "Thanks",
    textArabic: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ",
    textEnglish: "All praise is for Allah, Lord of the worlds.",
    context: "Express gratitude to Allah for His blessings"
  }
];

export default function DuasPage() {
  const categories = Array.from(new Set(duas.map(d => d.category)));

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
            Daily Duas
          </h1>
          <p className="text-lg md:text-xl font-arabic text-primary mb-2">
            أدعية يومية
          </p>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Essential supplications for daily life. Memorize and recite these to stay connected with Allah throughout your day.
          </p>
        </div>

        {/* Duas Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {duas.map((dua) => (
            <Card 
              key={dua.id}
              className="hover:shadow-lg transition-all duration-200 hover:-translate-y-1 border-t-2 border-t-accent overflow-hidden"
              data-testid={`card-dua-${dua.id}`}
            >
              <CardHeader className="space-y-2 pb-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <CardTitle className="text-xl font-arabic text-right leading-relaxed mb-2">
                      {dua.titleArabic}
                    </CardTitle>
                    <CardDescription className="text-base font-medium text-foreground">
                      {dua.titleEnglish}
                    </CardDescription>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    className="flex-shrink-0"
                    data-testid={`button-bookmark-${dua.id}`}
                  >
                    <BookmarkPlus className="h-5 w-5" />
                  </Button>
                </div>
                <Badge className="w-fit bg-accent/20 text-accent-foreground border-accent/30">
                  {dua.category}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-muted/30 rounded-lg p-4 border border-border">
                  <p 
                    className="text-xl md:text-2xl font-arabic text-right leading-loose mb-3"
                    lang="ar"
                    dir="rtl"
                  >
                    {dua.textArabic}
                  </p>
                  <p className="text-sm md:text-base text-muted-foreground italic">
                    {dua.textEnglish}
                  </p>
                </div>
                <p className="text-xs md:text-sm text-secondary bg-primary/5 p-3 rounded-md border-l-2 border-primary">
                  {dua.context}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
