import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { BookText, Loader2, AlertCircle } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { fetchHadithBook } from "@/utils/hadithCache";

const SAHIH_BUKHARI_BOOKS = [
  { number: 1, name: "Revelation", range: "1-7" },
  { number: 2, name: "Belief", range: "8-58" },
  { number: 3, name: "Knowledge", range: "59-134" },
  { number: 4, name: "Ablutions (Wudu')", range: "135-247" },
  { number: 5, name: "Bathing (Ghusl)", range: "248-293" },
  { number: 6, name: "Menstrual Periods", range: "294-333" },
  { number: 7, name: "Tayammum", range: "334-348" },
  { number: 8, name: "Prayers (Salat)", range: "349-520" },
  { number: 9, name: "Times of Prayers", range: "522-602" },
  { number: 10, name: "Call to Prayers (Adhaan)", range: "603-875" },
];

export default function HadithPage() {
  const [selectedBook, setSelectedBook] = useState<number | null>(null);

  const { data: araBook, isLoading: araLoading } = useQuery({
    queryKey: ['/hadith/ara', selectedBook],
    queryFn: () => selectedBook ? fetchHadithBook(selectedBook, 'ara') : null,
    enabled: selectedBook !== null,
  });

  const { data: engBook, isLoading: engLoading } = useQuery({
    queryKey: ['/hadith/eng', selectedBook],
    queryFn: () => selectedBook ? fetchHadithBook(selectedBook, 'eng') : null,
    enabled: selectedBook !== null,
  });

  const { data: urdBook, isLoading: urdLoading } = useQuery({
    queryKey: ['/hadith/urd', selectedBook],
    queryFn: () => selectedBook ? fetchHadithBook(selectedBook, 'urd') : null,
    enabled: selectedBook !== null,
  });

  const isLoading = araLoading || engLoading || urdLoading;

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <div className="flex items-center justify-center w-14 h-14 rounded-full bg-primary/10 border-2 border-accent">
              <BookText className="h-7 w-7 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                Sahih al-Bukhari
              </h1>
              <p className="text-lg md:text-xl font-arabic text-primary mt-1">
                صحيح البخاري
              </p>
            </div>
          </div>
          <p className="text-base md:text-lg text-muted-foreground max-w-3xl">
            The most authentic collection of Hadith (sayings and actions of Prophet Muhammad ﷺ), 
            compiled by Imam Muhammad ibn Ismail al-Bukhari. Select a book below to explore the hadiths.
          </p>
        </div>

        {/* Books List */}
        <Accordion 
          type="single" 
          collapsible 
          className="space-y-4"
          onValueChange={(value) => {
            if (value) {
              const bookNum = parseInt(value.replace('book-', ''));
              setSelectedBook(bookNum);
            }
          }}
        >
          {SAHIH_BUKHARI_BOOKS.map((book) => (
            <AccordionItem
              key={book.number}
              value={`book-${book.number}`}
              className="bg-card rounded-xl border-l-4 border-l-accent shadow-md hover:shadow-lg transition-all overflow-hidden"
              data-testid={`accordion-hadith-book-${book.number}`}
            >
              <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-muted/30 data-[state=open]:border-b">
                <div className="flex items-center justify-between w-full gap-4">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 border-2 border-accent flex-shrink-0">
                      <span className="text-lg font-bold text-primary">{book.number}</span>
                    </div>
                    <div className="text-left">
                      <h3 className="text-xl md:text-2xl font-semibold text-foreground">
                        {book.name}
                      </h3>
                      <Badge variant="outline" className="mt-1">
                        Hadiths {book.range}
                      </Badge>
                    </div>
                  </div>
                </div>
              </AccordionTrigger>

              <AccordionContent className="px-6 py-6 bg-gradient-to-b from-background to-muted/20">
                {isLoading && selectedBook === book.number ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : araBook && engBook && urdBook && selectedBook === book.number ? (
                  <div className="space-y-6">
                    {engBook.hadiths.map((hadith, index) => {
                      const araHadith = araBook.hadiths[index];
                      const urdHadith = urdBook.hadiths[index];
                      
                      return (
                        <div
                          key={hadith.hadithnumber}
                          className="bg-card rounded-lg p-6 md:p-8 shadow-sm hover:shadow-md transition-all border border-border"
                          data-testid={`hadith-card-${hadith.hadithnumber}`}
                        >
                          {/* Arabic Text - Top with Large Gold Font */}
                          {araHadith && (
                            <div className="mb-6 p-6 rounded-lg bg-gradient-to-br from-accent/10 to-accent/5 border-2 border-accent/30">
                              <p
                                className="text-2xl md:text-3xl lg:text-4xl font-arabic text-accent text-right leading-loose"
                                lang="ar"
                                dir="rtl"
                              >
                                {araHadith.text}
                              </p>
                            </div>
                          )}

                          {/* Urdu Text - Center */}
                          {urdHadith && (
                            <div className="mb-4 p-5 rounded-lg bg-muted/30 border border-border">
                              <Badge variant="outline" className="mb-3">اردو</Badge>
                              <p
                                className="text-lg md:text-xl font-urdu text-right leading-loose"
                                lang="ur"
                                dir="rtl"
                              >
                                {urdHadith.text}
                              </p>
                            </div>
                          )}

                          {/* English Text - Bottom (smaller) */}
                          <div className="p-5 rounded-lg bg-background/60 border border-border">
                            <Badge variant="outline" className="mb-3">English</Badge>
                            <p className="text-sm md:text-base leading-relaxed text-muted-foreground">
                              {hadith.text}
                            </p>
                          </div>

                          {/* Footer: Book Name + Hadith Number */}
                          <div className="mt-4 pt-4 border-t border-border/50 flex items-center justify-between text-sm text-muted-foreground">
                            <span className="font-medium">{book.name}</span>
                            <span className="flex items-center gap-2">
                              <Badge variant="secondary" className="text-xs">
                                #{hadith.hadithnumber}
                              </Badge>
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : selectedBook === book.number ? (
                  <div className="flex items-center gap-3 p-6 bg-destructive/10 rounded-lg border border-destructive/20">
                    <AlertCircle className="h-6 w-6 text-destructive flex-shrink-0" />
                    <p className="text-destructive">
                      Failed to load hadiths. Please try again.
                    </p>
                  </div>
                ) : null}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </div>
  );
}
