import { useState, useMemo } from "react";
import { BookmarkCheck, Play, Pause, Bookmark, Volume2 } from "lucide-react";
import { SearchBar } from "@/components/SearchBar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { FeaturedAyah } from "@/components/FeaturedAyah";
import { RamadanCountdown } from "@/components/RamadanCountdown";
import { useBookmarks } from "@/hooks/useBookmarks";
import { useAudioPlayer } from "@/hooks/useAudioPlayer";
import { RECITERS, getReciterById } from "@/config/reciters";
import quranData from "@/data/quran.json";
import type { Surah } from "@shared/schema";
import type { QuranData } from "@shared/schema";

const data = quranData as QuranData;

function formatTime(seconds: number): string {
  if (!seconds || !isFinite(seconds)) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export default function QuranPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showBookmarksOnly, setShowBookmarksOnly] = useState(false);
  const { isBookmarked, toggleBookmark, bookmarks } = useBookmarks();
  const { 
    selectedReciterId, 
    currentSurahNumber, 
    isPlaying, 
    isLoading,
    currentTime,
    duration,
    play,
    stop,
    seek,
    changeReciter 
  } = useAudioPlayer();

  const filteredSurahs = useMemo(() => {
    let surahs = data.surahs;

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      surahs = surahs.filter(
        (surah) =>
          surah.name.includes(query) ||
          surah.englishName.toLowerCase().includes(query) ||
          surah.englishNameTranslation.toLowerCase().includes(query) ||
          surah.number.toString() === query
      );
    }

    if (showBookmarksOnly) {
      const bookmarkedNumbers = new Set(bookmarks.map(b => b.surahNumber));
      surahs = surahs.filter(surah => bookmarkedNumbers.has(surah.number));
    }

    return surahs;
  }, [searchQuery, showBookmarksOnly, bookmarks]);

  const handlePlay = (surah: Surah) => {
    play(surah.number);
  };

  const currentReciter = getReciterById(selectedReciterId);

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Featured Qur'anic Verse */}
        <div className="mb-8">
          <FeaturedAyah />
        </div>

        {/* Ramadan Countdown Timer */}
        <div className="mb-8">
          <RamadanCountdown />
        </div>

        {/* Search & Filter Header */}
        <div className="mb-8 space-y-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
                The Noble Quran
              </h1>
              <p className="text-2xl md:text-3xl font-arabic text-primary">
                القرآن الكريم
              </p>
            </div>
            <div className="flex items-center gap-2">
              {/* Reciter Selector */}
              <Select value={selectedReciterId} onValueChange={changeReciter}>
                <SelectTrigger 
                  className="w-[220px] bg-card border-accent/30 hover-elevate"
                  data-testid="select-reciter"
                >
                  <div className="flex items-center gap-2">
                    <Volume2 className="h-4 w-4 text-accent" />
                    <SelectValue />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  {RECITERS.map((reciter) => (
                    <SelectItem 
                      key={reciter.id} 
                      value={reciter.id}
                      data-testid={`reciter-${reciter.id}`}
                    >
                      <div className="flex flex-col">
                        <span className="font-medium">{reciter.name}</span>
                        <span className="text-xs text-muted-foreground font-arabic">
                          {reciter.arabicName}
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                variant={showBookmarksOnly ? "default" : "outline"}
                size="icon"
                onClick={() => setShowBookmarksOnly(!showBookmarksOnly)}
                className="rounded-full"
                data-testid="button-toggle-bookmarks"
              >
                <BookmarkCheck className="h-5 w-5" />
              </Button>
            </div>
          </div>
          <SearchBar value={searchQuery} onChange={setSearchQuery} />
        </div>

        {/* Current Reciter Badge */}
        <div className="mb-6 flex items-center justify-center">
          <Badge variant="outline" className="text-sm px-4 py-2 bg-accent/10 border-accent">
            <Volume2 className="h-3 w-3 mr-2" />
            Now playing: {currentReciter.name}
          </Badge>
        </div>

        {/* Audio Player (when playing) */}
        {currentSurahNumber !== null && (
          <div className="mb-6 bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 rounded-2xl p-6 border border-accent/20 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Currently Playing</p>
                <p className="text-lg font-semibold text-foreground">
                  Surah {data.surahs.find(s => s.number === currentSurahNumber)?.englishName || currentSurahNumber}
                </p>
                <p className="text-xs text-muted-foreground font-arabic">
                  {currentReciter.arabicName}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={stop}
                className="rounded-full hover:bg-destructive/20 hover:text-destructive"
                data-testid="button-stop-audio"
              >
                <Pause className="h-5 w-5" />
              </Button>
            </div>
            
            {/* Progress Bar */}
            <div className="space-y-2">
              <Progress 
                value={duration > 0 ? (currentTime / duration) * 100 : 0} 
                className="h-2 cursor-pointer"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const percent = (e.clientX - rect.left) / rect.width;
                  seek(percent * duration);
                }}
                data-testid="progress-audio"
              />
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span data-testid="text-current-time">{formatTime(currentTime)}</span>
                <span data-testid="text-duration">{formatTime(duration)}</span>
              </div>
            </div>
          </div>
        )}

        {/* Surah Accordion List */}
        {filteredSurahs.length === 0 ? (
          <div className="text-center py-16 bg-muted/30 rounded-xl">
            <p className="text-xl text-muted-foreground" data-testid="text-no-results">
              {showBookmarksOnly
                ? "No bookmarked surahs yet. Bookmark your favorite surahs to find them here."
                : "No surahs found. Try a different search term."}
            </p>
          </div>
        ) : (
          <Accordion type="single" collapsible className="space-y-4">
            {filteredSurahs.map((surah) => {
              const isSurahPlaying = currentSurahNumber === surah.number && isPlaying;
              const isSurahLoading = currentSurahNumber === surah.number && isLoading;
              const surahIsBookmarked = isBookmarked(surah.number);
              
              return (
                <AccordionItem 
                  key={surah.number} 
                  value={`surah-${surah.number}`}
                  className="bg-card rounded-xl border-l-4 border-l-accent shadow-md hover:shadow-lg transition-all overflow-hidden"
                  data-testid={`accordion-surah-${surah.number}`}
                >
                  <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-muted/30 data-[state=open]:border-b">
                    <div className="flex items-center justify-between w-full gap-4">
                      <div className="flex items-center gap-4">
                        {/* Surah Number */}
                        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 border-2 border-accent flex-shrink-0">
                          <span className="text-lg font-bold text-primary">{surah.number}</span>
                        </div>
                        
                        {/* Surah Names */}
                        <div className="text-left">
                          <h3 className="text-xl md:text-2xl font-arabic font-semibold text-foreground" lang="ar" dir="rtl">
                            {surah.name}
                          </h3>
                          <p className="text-sm md:text-base text-muted-foreground">
                            {surah.englishName} • {surah.englishNameTranslation}
                          </p>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                        <Badge variant="outline" className="hidden sm:inline-flex">
                          {surah.numberOfAyahs} verses • {surah.revelationType}
                        </Badge>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleBookmark(surah.number);
                          }}
                          className="rounded-full"
                          data-testid={`button-bookmark-${surah.number}`}
                        >
                          <Bookmark className={`h-5 w-5 ${surahIsBookmarked ? 'fill-accent text-accent' : ''}`} />
                        </Button>
                        <Button
                          variant={isSurahPlaying ? "default" : "outline"}
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            handlePlay(surah);
                          }}
                          disabled={isSurahLoading}
                          className="rounded-full"
                          data-testid={`button-play-${surah.number}`}
                        >
                          {isSurahLoading ? (
                            <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                          ) : isSurahPlaying ? (
                            <Pause className="h-4 w-4" />
                          ) : (
                            <Play className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </AccordionTrigger>
                  
                  <AccordionContent className="px-6 py-6 bg-gradient-to-b from-background to-muted/20">
                    {/* Bismillah */}
                    {surah.number !== 1 && surah.number !== 9 && (
                      <div className="text-center mb-8">
                        <p className="text-2xl md:text-3xl font-arabic text-accent" lang="ar" dir="rtl">
                          بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                        </p>
                        <p className="text-sm text-muted-foreground mt-2">
                          In the name of Allah, the Most Gracious, the Most Merciful
                        </p>
                      </div>
                    )}

                    {/* Ayahs */}
                    <div className="space-y-6">
                      {surah.ayahs.map((ayah, index) => (
                        <div 
                          key={index}
                          className="bg-card rounded-lg p-4 md:p-6 border border-border"
                        >
                          <div className="flex items-start gap-3 mb-3">
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-accent/20 border border-accent flex-shrink-0">
                              <span className="text-sm font-semibold text-accent">{index + 1}</span>
                            </div>
                          </div>
                          <p 
                            className="text-xl md:text-2xl font-arabic text-right leading-loose mb-4"
                            lang="ar"
                            dir="rtl"
                          >
                            {ayah.text}
                          </p>
                          <p className="text-sm md:text-base text-secondary leading-relaxed font-serif">
                            {ayah.translation}
                          </p>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        )}
      </div>
    </div>
  );
}
