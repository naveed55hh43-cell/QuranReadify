import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Clock, MapPin, Calendar as CalendarIcon } from "lucide-react";
import { format } from "date-fns";

interface PrayerTimes {
  Fajr: string;
  Sunrise?: string;
  Dhuhr: string;
  Asr: string;
  Sunset?: string;
  Maghrib: string;
  Isha: string;
  Imsak?: string;
  Midnight?: string;
  Firstthird?: string;
  Lastthird?: string;
  [key: string]: string | undefined;
}

interface HijriDate {
  date: string;
  format: string;
  day: string;
  weekday: {
    en: string;
    ar: string;
  };
  month: {
    number: number;
    en: string;
    ar: string;
  };
  year: string;
  designation: {
    abbreviated: string;
    expanded: string;
  };
}

interface PrayerTimeData {
  timings: PrayerTimes;
  date: {
    readable: string;
    timestamp: string;
    hijri: HijriDate;
    gregorian: {
      date: string;
      format: string;
      day: string;
      weekday: { en: string };
      month: { number: number; en: string };
      year: string;
    };
  };
  meta: {
    timezone: string;
  };
}

const prayerIcons = {
  Fajr: "🌅",
  Dhuhr: "☀️",
  Asr: "🌤️",
  Maghrib: "🌆",
  Isha: "🌙"
};

const prayerNames = {
  Fajr: { en: "Fajr", ar: "الفجر" },
  Dhuhr: { en: "Dhuhr", ar: "الظهر" },
  Asr: { en: "Asr", ar: "العصر" },
  Maghrib: { en: "Maghrib", ar: "المغرب" },
  Isha: { en: "Isha", ar: "العشاء" }
};

export default function CalendarPage() {
  const { data, isLoading, error } = useQuery<{ data: PrayerTimeData }>({
    queryKey: ['/api/prayer-times'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-6">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-background py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="border-destructive">
            <CardHeader>
              <CardTitle>Unable to Load Prayer Times</CardTitle>
              <CardDescription>
                Please check your internet connection and try again.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }

  const { timings, date: dateInfo } = data.data;
  const today = new Date();

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
            Prayer Times & Calendar
          </h1>
          <p className="text-lg md:text-xl font-arabic text-primary">
            مواقيت الصلاة والتقويم
          </p>
        </div>

        {/* Date Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Gregorian Date */}
          <Card className="border-l-4 border-l-primary">
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <CalendarIcon className="h-5 w-5 text-primary" />
                <CardTitle className="text-lg">Gregorian Date</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-foreground mb-2">
                {format(today, 'MMMM d, yyyy')}
              </p>
              <p className="text-muted-foreground">
                {format(today, 'EEEE')}
              </p>
            </CardContent>
          </Card>

          {/* Hijri Date */}
          <Card className="border-l-4 border-l-accent bg-gradient-to-br from-background to-accent/5">
            <CardHeader>
              <div className="flex items-center gap-2 mb-2">
                <CalendarIcon className="h-5 w-5 text-accent" />
                <CardTitle className="text-lg">Hijri Date</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-2xl md:text-3xl font-arabic text-right mb-2" dir="rtl" lang="ar">
                {dateInfo.hijri.day} {dateInfo.hijri.month.ar} {dateInfo.hijri.year} {dateInfo.hijri.designation.abbreviated}
              </p>
              <p className="text-base md:text-lg text-muted-foreground">
                {dateInfo.hijri.day} {dateInfo.hijri.month.en} {dateInfo.hijri.year} {dateInfo.hijri.designation.abbreviated}
              </p>
              <p className="text-sm text-muted-foreground mt-1 font-arabic" dir="rtl">
                {dateInfo.hijri.weekday.ar}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Prayer Times */}
        <Card className="border-t-2 border-t-primary">
          <CardHeader className="bg-gradient-to-r from-primary/5 to-primary/10 border-b">
            <div className="flex items-center gap-3">
              <Clock className="h-6 w-6 text-primary" />
              <div>
                <CardTitle className="text-2xl">Today's Prayer Times</CardTitle>
                <CardDescription className="text-base">
                  Times are for your current location
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {(Object.keys(timings) as Array<keyof PrayerTimes>).map((prayer) => {
                const time = timings[prayer];
                if (!time || prayer === 'Sunrise' || prayer === 'Sunset' || prayer === 'Imsak' || prayer === 'Midnight' || prayer === 'Firstthird' || prayer === 'Lastthird') {
                  return null;
                }

                return (
                  <div
                    key={prayer}
                    className="flex items-center justify-between p-6 hover:bg-muted/30 transition-colors"
                    data-testid={`prayer-time-${String(prayer).toLowerCase()}`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="text-4xl" role="img" aria-label={String(prayer)}>
                        {prayerIcons[prayer as keyof typeof prayerIcons] || "🕌"}
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-foreground">
                          {prayerNames[prayer as keyof typeof prayerNames]?.en || prayer}
                        </h3>
                        <p className="text-lg font-arabic text-muted-foreground">
                          {prayerNames[prayer as keyof typeof prayerNames]?.ar || prayer}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl md:text-3xl font-bold text-primary">
                        {time}
                      </p>
                      <Badge variant="outline" className="mt-1">
                        24-hour
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Location Note */}
        <Card className="bg-muted/30">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm text-muted-foreground">
                  Prayer times are calculated based on your browser's location. 
                  Times may vary slightly depending on calculation methods. 
                  Please verify with your local mosque for precise timings.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
