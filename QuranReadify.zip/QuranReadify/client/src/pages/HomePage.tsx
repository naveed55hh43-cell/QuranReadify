import { useState, useMemo } from "react";
import { BookOpen, BookmarkCheck } from "lucide-react";
import { SearchBar } from "@/components/SearchBar";
import { SurahCard } from "@/components/SurahCard";
import { SurahDetail } from "@/components/SurahDetail";
import { DarkModeToggle } from "@/components/DarkModeToggle";
import { Button } from "@/components/ui/button";
import { useBookmarks } from "@/hooks/useBookmarks";
import { useAudioPlayer } from "@/hooks/useAudioPlayer";
import quranData from "@/data/quran.json";
import type { Surah } from "@shared/schema";
import type { QuranData } from "@shared/schema";

const data = quranData as QuranData;

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const [showBookmarksOnly, setShowBookmarksOnly] = useState(false);
  const { isBookmarked, toggleBookmark, bookmarks } = useBookmarks();
  const { currentAudio, isPlaying, play } = useAudioPlayer();

  const filteredSurahs = useMemo(() => {
    let surahs = data.surahs;

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      surahs = surahs.filter(
        (surah) =>
          surah.name.includes(query) ||
          surah.englishName.toLowerCase().includes(query) ||
          surah.englishNameTranslation.toLowerCase().includes(query) ||
          surah.number.toString() === query
      );
    }

    if (showBookmarksOnly) {
      const bookmarkedNumbers = new Set(bookmarks.map(b => b.surahNumber));
      surahs = surahs.filter(surah => bookmarkedNumbers.has(surah.number));
    }

    return surahs;
  }, [searchQuery, showBookmarksOnly, bookmarks]);

  const handleSurahClick = (surah: Surah) => {
    setSelectedSurah(surah);
  };

  const handlePlay = (surah: Surah) => {
    play(surah.audio);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-card/95 backdrop-blur-md border-b">
        <div className="max-w-4xl mx-auto px-4 md:px-8 py-4 md:py-6">
          <div className="flex items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-3">
              <BookOpen className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl md:text-3xl font-arabic font-bold text-foreground" data-testid="text-app-title-arabic">
                  القرآن الكريم
                </h1>
                <p className="text-sm md:text-base font-medium text-muted-foreground" data-testid="text-app-title-english">
                  The Noble Quran
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={showBookmarksOnly ? "default" : "outline"}
                size="icon"
                onClick={() => setShowBookmarksOnly(!showBookmarksOnly)}
                className="rounded-full"
                data-testid="button-toggle-bookmarks"
              >
                <BookmarkCheck className="h-5 w-5" />
              </Button>
              <DarkModeToggle />
            </div>
          </div>
          <SearchBar value={searchQuery} onChange={setSearchQuery} />
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 md:px-8 py-8">
        {filteredSurahs.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-xl text-muted-foreground" data-testid="text-no-results">
              {showBookmarksOnly
                ? "No bookmarked surahs yet. Bookmark your favorite surahs to find them here."
                : "No surahs found. Try a different search term."}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredSurahs.map((surah) => (
              <SurahCard
                key={surah.number}
                surah={surah}
                isPlaying={currentAudio === surah.audio && isPlaying}
                isBookmarked={isBookmarked(surah.number)}
                onPlay={() => handlePlay(surah)}
                onBookmark={() => toggleBookmark(surah.number)}
                onClick={() => handleSurahClick(surah)}
              />
            ))}
          </div>
        )}
      </main>

      {selectedSurah && (
        <SurahDetail
          surah={selectedSurah}
          onClose={() => setSelectedSurah(null)}
          isPlaying={currentAudio === selectedSurah.audio && isPlaying}
          onPlay={() => handlePlay(selectedSurah)}
        />
      )}
    </div>
  );
}
