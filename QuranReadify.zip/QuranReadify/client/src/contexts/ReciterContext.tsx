import { createContext, useContext, ReactNode } from "react";

type ReciterContextType = {
  reciterName: string;
  reciterArabicName: string;
};

const ReciterContext = createContext<ReciterContextType | undefined>(undefined);

export function ReciterProvider({ children }: { children: ReactNode }) {
  const value = {
    reciterName: "Mishary Rashid Alafasy",
    reciterArabicName: "مشاري راشد العفاسي"
  };

  return (
    <ReciterContext.Provider value={value}>
      {children}
    </ReciterContext.Provider>
  );
}

export function useReciter() {
  const context = useContext(ReciterContext);
  if (!context) {
    throw new Error("useReciter must be used within ReciterProvider");
  }
  return context;
}
