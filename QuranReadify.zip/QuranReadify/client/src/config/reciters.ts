export interface Reciter {
  id: string;
  name: string;
  arabicName: string;
  urlTemplate: string;
  usePadding: boolean; // Whether to use 3-digit padding (001) or not (1)
}

export const RECITERS: Reciter[] = [
  {
    id: "alafasy",
    name: "Mishary Rashid Alafasy",
    arabicName: "مشاري بن راشد العفاسي",
    urlTemplate: "https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/{surahNumber}.mp3",
    usePadding: false // Islamic Network uses non-padded numbers (1, 2, 3...)
  },
  {
    id: "abdulbasit",
    name: "Abdul Basit Abdul Samad",
    arabicName: "عبد الباسط عبد الصمد",
    urlTemplate: "https://server7.mp3quran.net/basit/{surahNumber}.mp3",
    usePadding: true // mp3quran.net uses 3-digit padding (001, 002, 003...)
  },
  {
    id: "husary",
    name: "Mahmoud Khalil Al-Husary",
    arabicName: "محمود خليل الحصري",
    urlTemplate: "https://server13.mp3quran.net/husr/{surahNumber}.mp3",
    usePadding: true // mp3quran.net uses 3-digit padding (001, 002, 003...)
  },
  {
    id: "minshawi",
    name: "Mohamed Siddiq Al-Minshawi",
    arabicName: "محمد صديق المنشاوي",
    urlTemplate: "https://server10.mp3quran.net/minsh/{surahNumber}.mp3",
    usePadding: true // mp3quran.net uses 3-digit padding (001, 002, 003...)
  }
];

export const DEFAULT_RECITER_ID = "alafasy";

export function getAudioUrl(reciterId: string, surahNumber: number): string {
  const reciter = RECITERS.find(r => r.id === reciterId) || RECITERS[0];
  
  // Use 3-digit padding only for reciters that require it
  const formattedNumber = reciter.usePadding 
    ? surahNumber.toString().padStart(3, '0')
    : surahNumber.toString();
  
  return reciter.urlTemplate.replace('{surahNumber}', formattedNumber);
}

export function getLocalAudioUrl(reciterId: string, surahNumber: number): string {
  // Local fallback always uses 3-digit padding
  const paddedNumber = surahNumber.toString().padStart(3, '0');
  return `/audio/${reciterId}/${paddedNumber}.mp3`;
}

export function getReciterById(reciterId: string): Reciter {
  return RECITERS.find(r => r.id === reciterId) || RECITERS[0];
}
