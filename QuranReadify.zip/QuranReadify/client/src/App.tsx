import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { ReciterProvider } from "@/contexts/ReciterContext";
import { Navigation } from "@/components/Navigation";
import QuranPage from "@/pages/QuranPage";
import HadithPage from "@/pages/HadithPage";
import DuasPage from "@/pages/DuasPage";
import CalendarPage from "@/pages/CalendarPage";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={QuranPage} />
      <Route path="/hadith" component={HadithPage} />
      <Route path="/duas" component={DuasPage} />
      <Route path="/calendar" component={CalendarPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <ReciterProvider>
          <TooltipProvider>
            <Navigation />
            <Toaster />
            <Router />
          </TooltipProvider>
        </ReciterProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
