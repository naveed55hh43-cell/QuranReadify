import { z } from "zod";

export const ayahSchema = z.object({
  number: z.number(),
  text: z.string(),
  translation: z.string(),
});

export const surahSchema = z.object({
  number: z.number(),
  name: z.string(),
  englishName: z.string(),
  englishNameTranslation: z.string(),
  revelationType: z.string(),
  numberOfAyahs: z.number(),
  audio: z.string(),
  ayahs: z.array(ayahSchema),
});

export const bookmarkSchema = z.object({
  surahNumber: z.number(),
  timestamp: z.number(),
});

export type Ayah = z.infer<typeof ayahSchema>;
export type Surah = z.infer<typeof surahSchema>;
export type Bookmark = z.infer<typeof bookmarkSchema>;

export interface QuranData {
  surahs: Surah[];
}
