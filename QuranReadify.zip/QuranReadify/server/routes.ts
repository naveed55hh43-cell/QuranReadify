import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Prayer times endpoint using Aladhan API
  app.get("/api/prayer-times", async (req, res) => {
    try {
      const today = new Date();
      const dateStr = `${String(today.getDate()).padStart(2, '0')}-${String(today.getMonth() + 1).padStart(2, '0')}-${today.getFullYear()}`;
      
      // Default to London, but can be extended to use user location
      const city = req.query.city as string || 'London';
      const country = req.query.country as string || 'UK';
      const method = req.query.method as string || '2'; // Islamic Society of North America
      
      const apiUrl = `https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=${encodeURIComponent(country)}&method=${method}&date=${dateStr}`;
      
      const response = await fetch(apiUrl);
      
      if (!response.ok) {
        console.error(`Failed to fetch prayer times from Aladhan: ${response.status}`);
        return res.status(response.status).json({ error: "Prayer times not available" });
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Error fetching prayer times:", error);
      res.status(500).json({ error: "Failed to load prayer times" });
    }
  });

  // Audio proxy endpoint to handle CORS issues with external CDN
  app.get("/api/audio/:surahNumber", async (req, res) => {
    const surahNumber = parseInt(req.params.surahNumber);
    
    if (isNaN(surahNumber) || surahNumber < 1 || surahNumber > 114) {
      return res.status(400).json({ error: "Invalid surah number" });
    }

    const audioUrl = `https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${surahNumber}.mp3`;
    
    try {
      const response = await fetch(audioUrl);
      
      if (!response.ok) {
        console.error(`Failed to fetch audio from CDN: ${response.status}`);
        return res.status(response.status).json({ error: "Audio not available" });
      }

      // Set appropriate headers for audio streaming
      res.setHeader('Content-Type', 'audio/mpeg');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Cache-Control', 'public, max-age=31536000'); // Cache for 1 year
      
      // Stream the audio data
      if (response.body) {
        const reader = response.body.getReader();
        
        const pump = async () => {
          const { done, value } = await reader.read();
          if (done) {
            res.end();
            return;
          }
          res.write(Buffer.from(value));
          await pump();
        };
        
        await pump();
      } else {
        const buffer = await response.arrayBuffer();
        res.send(Buffer.from(buffer));
      }
    } catch (error) {
      console.error("Error proxying audio:", error);
      res.status(500).json({ error: "Failed to load audio" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
