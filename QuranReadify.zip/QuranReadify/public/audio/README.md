# Quran Audio Files

This directory should contain audio files for all 114 surahs from 4 different reciters.

## Directory Structure

```
public/audio/
├── alafasy/
│   ├── 001.mp3
│   ├── 002.mp3
│   └── ... (up to 114.mp3)
├── husary/
│   ├── 001.mp3
│   ├── 002.mp3
│   └── ... (up to 114.mp3)
├── minshawi/
│   ├── 001.mp3
│   ├── 002.mp3
│   └── ... (up to 114.mp3)
└── abdulbasit/
    ├── 001.mp3
    ├── 002.mp3
    └── ... (up to 114.mp3)
```

## File Naming Convention

- Files must be named with 3-digit zero-padded surah numbers
- Examples: `001.mp3`, `002.mp3`, `010.mp3`, `114.mp3`
- Format: MP3
- All files should be in the respective reciter's directory

## Reciters

1. **Mishary Rashid Alafasy** (مشاري راشد العفاسي) - `alafasy/`
2. **Mahmoud Khalil Al-Husary** (محمود خليل الحصري) - `husary/`
3. **Mohamed Siddiq Al-Minshawi** (محمد صديق المنشاوي) - `minshawi/`
4. **Abdul Basit Abdul Samad** (عبد الباسط عبد الصمد) - `abdulbasit/`

## Audio Sources

You can download Quran recitations from:
- https://everyayah.com/
- https://quranicaudio.com/
- https://mp3quran.net/

## Notes

- The app will automatically select audio based on the user's reciter preference
- If an audio file is missing, the app will show a toast notification
- All audio files are served from local Replit static assets (no CORS issues)
